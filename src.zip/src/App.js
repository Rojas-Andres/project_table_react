
import logo from './logo.svg';
import './App.css';
import React,{Component } from 'react'

import { PaginationTable } from './PaginationTable'
//import { Nueva } from './componentes/nueva'

//import  MyComponent from './componentes/connection'

//import { Title } from './title'
import './bootstrap.min.css'

function App() {
  return (
    <div  className='App'>
      
       <PaginationTable /> 
    </div>
  );
}

export default App;
