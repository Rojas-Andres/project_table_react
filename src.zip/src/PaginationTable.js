import React, { useMemo ,useEffect  ,useState,useCallback} from 'react'
import { COLUMNS } from './columns'
import { useTable ,useSortBy, useFilters, useGlobalFilter, useAsyncDebounce ,usePagination  } from 'react-table'
import MOCK_DATA from './MOCK_DATA.json'
//import Prueba from './prueba'
//import './table.css'
import './bootstrap.min.css'
//import myComponent from './connection'
import axios from 'axios';
import { of } from 'rxjs';
import { fromFetch } from 'rxjs/fetch';
import { switchMap, catchError } from 'rxjs/operators';

// Define a default UI for filtering
function GlobalFilter({
    preGlobalFilteredRows,
    globalFilter,
    setGlobalFilter,
}) {
    const count = preGlobalFilteredRows.length
    const [value, setValue] = React.useState(globalFilter)
    const onChange = useAsyncDebounce(value => {
        setGlobalFilter(value || undefined)
    }, 200)

    return (
        <span>
            Search:{' '}
            <input
                className="form-control"
                value={value || ""}
                onChange={e => {
                    setValue(e.target.value);
                    onChange(e.target.value);
                }}
                placeholder={`${count} records...`}
            />
        </span>
    )
}

function DefaultColumnFilter({
    column: { filterValue, preFilteredRows, setFilter },
}) {
    const count = preFilteredRows.length

    return (
        <input
            className="form-control"
            value={filterValue || ''}
            onChange={e => {
                setFilter(e.target.value || undefined)
            }}
            placeholder={`Search ${count} records...`}
        />
    )
}


export const PaginationTable = (props) => {
    
    const [items, setItems] = useState(null);
    const targetUrl = 'https://api.itbook.store/1.0/search/mongodb';
//'https://api.github.com/users?per_page=5'
    const data$ = fromFetch(targetUrl).pipe(
        switchMap(response => {
        if (response.ok) {
            // OK return data
            return response.json();
        } else {
            // Server is returning a status requiring the client to try something else.
            return of({ error: true, message: `Error ${response.status}` });
        }
        }),
        catchError(err => {
        // Network or other error, handle appropriately
        console.error(err);
        return of({ error: true, message: err.message })
        })
        );
        
        data$.subscribe({
        next: result => setItems( result.books),//console.log(result.books),
        complete: () => console.log('done')
        });
    //    const targetUrl = "https://cors-anywhere.herokuapp.com/"+'https://api.itbook.store/1.0/search/mongodb';

        /*
    const valores = async ()=>{
        await fetch(targetUrl,{
            mode:'no-cors'
        })
       .then(blob => blob.json())
       .then(data => {
        console.log("los datos son ",data.books)
         //console.log("El tituloe s",data.books);
         //document.querySelector("pre").innerHTML = JSON.stringify(data, null, 2);
        setItems( data.books)
         
       })
       .catch(e => {
         console.log(e);
         return e;
       })};
    valores();
    
    
    
    fetch(targetUrl)
   .then(blob => {
    console.log("ÑA DATAS SAESDASD",blob.json())
    })
   .catch(e => {
     console.log(e);
     return e;
   });
    Promise.resolve(fetch(targetUrl)
       .then(blob => blob.json())
       .then(data => {
      
         //console.log("El tituloe s",data.books);
         //document.querySelector("pre").innerHTML = JSON.stringify(data, null, 2);
         Promise.resolve(setItems( data.books))
         
       })
       .catch(e => {
         console.log(e);
         return e;
       }));
    
    const valores = async ()=>{
        await fetch(targetUrl)
       .then(blob => blob.json())
       .then(data => {
      
         //console.log("El tituloe s",data.books);
         //document.querySelector("pre").innerHTML = JSON.stringify(data, null, 2);
        setItems( data.books)
         
       })
       .catch(e => {
         console.log(e);
         return e;
       })};
    valores();
    
   fetch(targetUrl)
   .then(blob => {blob.json()
    setItems( data.books)
    })
   .catch(e => {
     console.log(e);
     return e;
   });
   */
    
   

    //console.log("adasdasdasdasdasdadsasdsda",items.title)
    //console.log("adasdasdasdasdasdadsasdsda",columns)
    console.log("A es: tal cosa",MOCK_DATA)
    console.log("LAS COLUMNAS SON",COLUMNS)
    
    const [books, setBooks] = useState(null);


    //const targetUrl = 'https://api.itbook.store/1.0/search/mongodb';
    

    const fetchData = async () => {
    const response = await axios.get(
      'https://api.itbook.store/1.0/search/mongodb'
    );
        setBooks(response.data.books);
    };
    
    console.log("estos son los libros maricon " , books)
    
    console.log("estos son los libros maricon 22222222222222222222222222222222222222" , items)

    const columns = COLUMNS
    const data = MOCK_DATA
    
    //Creamos una instancia de la tabla
    
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        //rows ,//Esta es para sin paginacion
        page,
        nextPage,
        previousPage, // Navegar en las paginas
        canNextPage, // Me indican si es posible avanzar
        canPreviousPage,
        prepareRow,
        pageOptions,
        setPageSize,//Ajusta el tamaño
        state,
        preGlobalFilteredRows,
        setGlobalFilter,
        
    } = useTable({
        columns,
        data
    },
    useFilters,
    useGlobalFilter
    ,useSortBy,
    usePagination)
    const { pageIndex , pageSize } = state

    return (
        
       
        <div class="container">
            <GlobalFilter
                preGlobalFilteredRows={preGlobalFilteredRows}
                globalFilter={state.globalFilter}
                setGlobalFilter={setGlobalFilter}
            />
            <table class="table" {...getTableProps()}>
                <thead class="thead-dark">
                    {/* Header de la tabla*/}

                    {headerGroups.map((headerGroup) => (
                        <tr {...headerGroup.getHeaderGroupProps()}>
                            {headerGroup.headers.map((column) => (
                                <th scope="row" {...column.getHeaderProps(column.getSortByToggleProps())}> {column.render('Header')}
                                
                                
                                <span>
                                    {column.isSorted ? (column.isSortedDesc ? '▲':'▼'):''}
                                </span>
                                
                                </th>
                            ))}
                            
                        </tr>
                    ))}

                </thead>
                {/* Traemos todos los registros uno a uno*/}
                <tbody {...getTableBodyProps()}>
                
                    {page.map((row) => {
                        prepareRow(row)
                        return (
                            <tr {...row.getRowProps()}>
                                {row.cells.map((cell) => {
                                    return <td {...cell.getCellProps()}> {cell.render('Cell')}</td>
                                })}

                            </tr>
                        )
                    })}
                 
                </tbody>
            </table>
            <div>
            {/* Esta parte es para definir la cantidad de valores que puede tomar al momento de mostrar */}
                <select value={pageSize} onChange={e=>setPageSize(Number(e.target.value))}>
                    {
                        [10,20,50,100].map(pageSize=>(
                            <option key={pageSize} value={pageSize}>
                                Mostrar {pageSize}
                            </option>
                        ))
                    }
                </select>
                {/* Esta parte definine el anterior y el siguiente de la tabla, el contador*/}
                <span >
                    Pagina{' '}
                    <strong >
                        {pageIndex + 1 } de {pageOptions.length}
                    </strong>{' '}
                </span>
                {/* Esta parte definine el anterior y el siguiente de la tabla, los bonotes de siguiente*/}
                <div class="btn-group">
                    <button type="button" class="btn btn-dark " onClick={()=>previousPage()} disabled={!canPreviousPage}> Anterior</button>
                    <button type="button"  class="btn btn-dark"  onClick={()=>nextPage()} disabled={!canNextPage}>Siguiente</button>
                
                </div>
            </div>
        </div>
    )
}
