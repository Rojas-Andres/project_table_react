export const COLUMNS = [
    {
        Header:'Title',
        accessor : 'title',
    },
    {
        Header:'Subtitle',
        accessor : 'subtitle',
    },
    {
        Header:'Isbn13',
        accessor : 'isbn13',
    },
    {
        Header:'Price',
        accessor : 'price',
    },
    {
        Header:'Url',
        accessor : 'url',
    }
]
